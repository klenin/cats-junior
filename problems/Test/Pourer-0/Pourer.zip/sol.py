def func0():
  fill(1)
  pour(1, 2)
  pourOut(2)
  pour(1, 2)
  if compare(2, u'!=', 45):
    func0()
func0()
