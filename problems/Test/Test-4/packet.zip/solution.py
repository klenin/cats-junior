while not objectPosition("wall", "inFrontOf"):
		while not objectPosition("wall", "inFrontOf"):
				forward(1)
		left(1)
