while not objectPosition("wall", "inFrontOf"):
		while not objectPosition("prize", "atTheRight"):
				forward(1)
		right(1)
		forward(1)
		left(2)
		forward(1)
		right(1)
		forward(1)
